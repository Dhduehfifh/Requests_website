
  # International Student Life Hub

  This is a code bundle for International Student Life Hub. The original project is available at https://www.figma.com/design/pFZvoM4l6eLtdeTAao7RAB/International-Student-Life-Hub.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  